﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    public class FilePreview
    {
        public double AlgorithmTime { get; set; }
        public int Size { get; set; }
        public string AlgorithmName { get; set; }

        public string LocalPath { get; set; }
    }
}
